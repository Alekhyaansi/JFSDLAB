package service;

public class BookRepository {

}
